/******************************************************************************************
* Copyright 2013-2017 Sensel, Inc
*
* Permission is hereby granted, free of charge, to any person obtaining a copy of this
* software and associated documentation files (the "Software"), to deal in the Software
* without restriction, including without limitation the rights to use, copy, modify, merge,
* publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
* to whom the Software is furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all copies or
* substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
* FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
* OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
******************************************************************************************/

#ifndef __SENSEL_DECOMPRESS_H___
#define __SENSEL_DECOMPRESS_H__

#include "sensel.h"

#ifdef __cplusplus
extern "C" {
#endif

  /*
   * Function   : senselInitDecompressionHandle
   * Parameters : handle: Sensel device handle where to allocate decompression handle
   * Return     : SENSEL_OK on success or error
   * Description: Allocates a decompression handle inside the device handle
   */
  SENSEL_API
  SenselStatus WINAPI senselInitDecompressionHandle(SENSEL_HANDLE handle, unsigned char *data);

  /*
   * Function   : senselFreeDecompressionHandle
   * Parameters : handle: Sensel device handle from which to free the decompression handle
   * Return     : SENSEL_OK on success or error
   * Description: Frees the decompression handle from the provided device handle
   */
  SENSEL_API
  SenselStatus WINAPI senselFreeDecompressionHandle(SENSEL_HANDLE handle);

  /*
   * Function   : senselDecompressionTriggerDetail
   * Parameters : handle: Sensel device handle
   *              data: Metadata in raw form
   * Return     : SENSEL_OK on success or error
   * Description: Notifies the decompression engine that a scan detail change was requested
   */
  SENSEL_API
  SenselStatus WINAPI senselDecompressionTriggerDetailChange(SENSEL_HANDLE handle, unsigned char *data);

  /*
   * Function   : senselDecompressFrame
   * Parameters : handle: Sensel device handle
   *              frame_data: Raw protocol payload to process
   *              data_size: Size of the payload
   *              content_mask: Content mask as reported for this frame
   *              data: Frame data to store the decompression result
   *              decompress_bytes_read: Will hold the number of bytes read from the payload
   * Return     : SENSEL_OK on success or error
   * Description: Decompresses the payload pointed to by frame_data and fills the FrameData structure
   *              accordingly.
   */
  SENSEL_API
  SenselStatus WINAPI senselDecompressFrame(SENSEL_HANDLE handle, unsigned char* frame_data, int data_size,
                                     unsigned char content_mask, SenselFrameData *data, unsigned int *decompress_bytes_read);

#ifdef __cplusplus
}
#endif


#endif //__SENSEL_DECOMPRESS_H__
